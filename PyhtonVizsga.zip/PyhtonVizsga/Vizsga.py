from abc import ABC,abstractmethod
from datetime import datetime
class Szoba(ABC):
    def __init__(self,ar:int,szobaszam:int):
        self.szobaszam=szobaszam
        self.ar=ar
        self.foglalt=False
class EgyagyasSzoba(Szoba):
    def __init__(self, ar, furdoszam=2, erkely=False, szobaszam=0):
        super().__init__(ar,szobaszam)
        self.ar = ar
        self.szobaszam = szobaszam
        self.furdoszam = furdoszam
        self.erkely = erkely

class KetagyasSzoba(Szoba):
    def __init__(self, ar, furdoszam=2, erkely=True, szobaszam=0):
        super().__init__(ar, szobaszam)
        self.ar = ar
        self.szobaszam = szobaszam
        self.furdoszam = furdoszam
        self.erkely = erkely

class Szalloda:
    def __init__(self,nev):
        self.nev=nev
        self.szobak = [EgyagyasSzoba(ar=40000, furdoszam=2, erkely=False, szobaszam=43),
                       EgyagyasSzoba(ar=40000, furdoszam=2, erkely=False, szobaszam=41),
                       EgyagyasSzoba(ar=40000, furdoszam=2, erkely=False, szobaszam=44),
                       EgyagyasSzoba(ar=40000, furdoszam=2, erkely=False, szobaszam=45),
                       EgyagyasSzoba(ar=40000, furdoszam=2, erkely=False, szobaszam=42),
                       KetagyasSzoba(ar=50000, furdoszam=3, erkely=True, szobaszam=143),
                       KetagyasSzoba(ar=50000, furdoszam=3, erkely=True, szobaszam=141),
                       KetagyasSzoba(ar=50000, furdoszam=3, erkely=True, szobaszam=144),
                       KetagyasSzoba(ar=50000, furdoszam=3, erkely=True, szobaszam=145),
                       KetagyasSzoba(ar=50000, furdoszam=3, erkely=True, szobaszam=142)
                      ]
    def __str__(self):
        return self.nev

    def SzobakFeltoltese(self):
        for szoba in self.szobak:
            print(f"Szoba {szoba.szobaszam}: Ár={szoba.ar},")
class Foglalas:

    def __init__(self,szobaszam,datum):
        self.szobaszam=szobaszam
        self.datum=datum
        self.foglaltszobak=[szobaszam,datum,
                            f" Szobaszám:{45}, Dátum:{'2023.12.21'}",
                            f" Szobaszám:{44}, Dátum:{'2023.12.11'}",
                            f" Szobaszám:{142}, Dátum:{'2023.12.24'}",
                            f" Szobaszám:{143}, Dátum:{'2023.12.15'}",
                            ]

    def FoglalasAdd(self,datum:str,szobaszam:int):
        try:
            foglalas_datum = datetime.strptime(datum, "%Y.%m.%d")
            today = datetime.today()
            if foglalas_datum > today:
                for szalloda_szoba in szalloda.szobak:
                    if szobaszam == szalloda_szoba.szobaszam and not szalloda_szoba.foglalt:
                        szalloda_szoba.foglalt = True
                        self.foglaltszobak.append((f"\nSzobaszám:{szobaszam}, Dátum: {foglalas_datum.strftime('%Y.%m.%d')}"))
                        print(f"Sikeres foglalás az ára {szalloda_szoba.ar}")
                        return
                print("A szobaszám nem érvényes vagy a szoba már foglalt.")
            else:
                print("A foglalás dátuma nem lehet kisebb vagy egyenlő a mai dátumnál.")
        except ValueError:
            print("Érvénytelen dátum formátum. Használja a következő formátumot: YYYY.MM.DD")
    def FoglalasLista(self):
        return self.foglaltszobak
    def Lemondas(self,szobaszam,datum:str):
        szobavan=False
        datumvan=False
        for foglalas_szoba in self.foglaltszobak:
            if foglalas_szoba==szobaszam:
                szobavan=True
        for foglalas_datum in self.foglaltszobak:
            if foglalas_datum == datum and szobavan==True:
                datumvan=True
        if datumvan==True:
            self.foglaltszobak.remove(datum)
        if szobavan==True and datumvan==True:
            self.foglaltszobak.remove(szobaszam)
        else:
         print("Nem sikerült")






szalloda = Szalloda("Bajka Hotel")
foglalas=Foglalas(f" Szobaszám:{43}, Dátum:{'2023.12.21'}",
                  f" Szobaszám:{41}, Dátum:{'2023.12.11'}",
                  )
while True:
    print("\n1. Foglalás leadása")
    print("2. Foglalások lekérdezése")
    print("3. Foglalás törlése")
    print("4. Szobák Listázása")
    print("0. Kilépés")
    valasztas = input("Válassz egy menüpontot: ")

    if valasztas == "1":
        szobaszam = int(input("Add meg a foglalni kívánt szoba számát: "))
        datum = str(input("Add meg a foglalni kívánt datumot: "))
        foglalas.FoglalasAdd(datum,szobaszam)
    elif valasztas == "2":
        print(f" Foglalt szobák {foglalas.FoglalasLista()}")
    elif valasztas == "3":
        szobaszam = int(input("Add meg a törölni kívánt szoba számát: "))
        datum = str(input("Add meg a törölni kívánt datumot: "))
        foglalas.Lemondas(szobaszam,datum)
    elif valasztas == "4":
        szalloda.SzobakFeltoltese()
    elif valasztas == "0":
        break
    else:
        print("Érvénytelen választás. Kérlek, válassz újra.")

